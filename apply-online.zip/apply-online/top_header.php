	<div class="page-header-top">
		<div class="grid-row clear-fix">
			<address>
				<a href="<?= SITE_URL ?>/tel:+44 7448 443723" class="phone-number"><i class="fa fa-phone"></i>+44 7448 443723</a>
				<a href="<?= SITE_URL ?>/mailto:info@ukesps.com" class="email"><i class="fa fa-envelope-o"></i>info@ukesps.com</a>
				&nbsp;&nbsp;<a href="<?= SITE_URL ?>/recru_panel/login"><i class="fa fa-envelope-o"></i>&nbsp;Recruiting? Post a job</a>
			</address>
			<div class="header-top-panel">
				<a href="<?= SITE_URL ?>/cart" class="fa fa-shopping-cart"><sup>0</sup></a>
				<a href="<?= SITE_URL ?>/login" class="fa fa-user login-icon"></a>
				<div id="top_social_links_wrapper">
					<div class="share-toggle-button"><i class="share-icon fa fa-share-alt"></i></div>
					<div class="cws_social_links"><a href="<?= SITE_URL ?>/https://plus.google.com/" class="cws_social_link" title="Google +"><i class="share-icon fa fa-google-plus" style="transform: matrix(0, 0, 0, 0, 0, 0);"></i></a><a href="<?= SITE_URL ?>/http://twitter.com/" class="cws_social_link" title="Twitter"><i class="share-icon fa fa-twitter"></i></a><a href="<?= SITE_URL ?>/http://facebook.com" class="cws_social_link" title="Facebook"><i class="share-icon fa fa-facebook"></i></a><a href="<?= SITE_URL ?>/http://dribbble.com" class="cws_social_link" title="Dribbble"><i class="share-icon fa fa-dribbble"></i></a></div>
				</div>
				<a href="#" class="search-open"><i class="fa fa-search"></i></a>
				<form action="#" class="clear-fix">
					<input type="text" placeholder="Search" class="clear-fix">
				</form>

			</div>
		</div>
	</div>